(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["/js/register"],{

/***/ "./resources/js/register.js":
/*!**********************************!*\
  !*** ./resources/js/register.js ***!
  \**********************************/
/*! no static exports found */
/***/ (function(module, exports) {

$(document).ready(function () {
  $('#tim_nama').keyup(function () {
    validateStep1();
  });
  $('#tim_institusi').keyup(function () {
    validateStep1();
  });
  $('#tim_kategori').change(function () {
    validateStep1();
  });
  $("#ketua_nim").keyup(function () {
    validateStep2();
  });
  $("#ketua_nama").keyup(function () {
    validateStep2();
  });
  $("#ketua_wa").keyup(function () {
    validateStep2();
  });
  $('#jumlah_anggota').on('change', function (e) {
    validateStep2();
    $("input[name^='member']").keyup(function () {
      validateStep2();
    });
  });
  $('#third_email').keyup(function () {
    validateStep3();
  });
  $('#third_password').keyup(function () {
    validateStep3();
  });
  $('#third_confirm').keyup(function () {
    validateStep3();
  });
});

function validateStep1() {
  var formNamaTim = $('#tim_nama').val().length;
  var formInstitusi = $('#tim_institusi').val().length;
  var formKategori = $('#tim_kategori').val();

  if (formNamaTim >= 3 && formInstitusi >= 6 && formKategori > 0) {
    $('#to-step-2').removeClass('disabled');
  } else {
    $('#to-step-2').addClass('disabled');
  }
}

function validateStep2() {
  var formNimKetua = $('#ketua_nim').val().length;
  var formNamaKetua = $('#ketua_nama').val().length;
  var formWaKetua = $('#ketua_wa').val().length;
  var formMemberData = $("div[id^='anggota-wrap-'").length;
  var formMember = [];
  var formMemberPass = false;

  for (i = 1; i <= formMemberData; i++) {
    var nim = $("input[name=\"member[".concat(i, "][nim]\"]")).val().length;
    var name = $("input[name=\"member[".concat(i, "][name]\"]")).val().length;

    if (nim >= 3 && name >= 6) {
      formMember[i - 1] = true;
    } else {
      formMember[i - 1] = false;
    }
  }

  if (formMember.length > 0 && formMember.indexOf(false) == -1) {
    formMemberPass = true;
  } else {
    formMemberPass = false;
  }

  if (formNimKetua > 3 && formNamaKetua >= 6 && formWaKetua >= 10 && formMemberPass) {
    $('#to-step-3').removeClass('disabled');
  } else {
    $('#to-step-3').addClass('disabled');
  }
}

function validateStep3() {
  var formEmail = $('#third_email').val().length;
  var formPassword = $('#third_password').val();
  var formPasswordConfirm = $('#third_confirm').val();

  if (formEmail >= 6 && formPassword.length >= 6 && formPasswordConfirm.length >= 6 && formPassword === formPasswordConfirm) {
    $('#submit').removeClass('disabled');
  } else {
    $('#submit').addClass('disabled');
  }
}

$('#jumlah_anggota').on('change', function (e) {
  // Jumlah inputan anggota saat ini
  var domCount = $("div[id^='anggota-wrap-'").length; // Kalau pilihan 0, hapus semuanya

  if (this.value == 0) {
    $('[id^=anggota-wrap-]').remove();
  } // Kalau input yang ditampilan < yang dipilih


  if (domCount < this.value) {
    for (i = domCount; i < this.value; ++i) {
      // Increment jumlah inputan anggota
      ++domCount; // Tambahkan set element berikut kedalam div 'anggota'

      $('#anggota').append("\n        <div id=\"anggota-wrap-".concat(domCount, "\" class=\"form-group row\">\n          <label class=\"col-sm-2 col-form-label\">Anggota ").concat(domCount, "</label>\n          <div class=\"col-sm-4\">\n            <input type=\"text\" placeholder=\"NIM Anggota ").concat(domCount, "\" name='member[").concat(domCount, "][nim]' class=\"form-control\" required minlength=\"3\" maxlength=\"100\">\n            <div class=\"invalid-feedback\">\n              Masukkan nim anggota ke-").concat(domCount, "\n            </div>\n          </div>\n          <div class=\"col-sm-6\">\n            <input type=\"text\" placeholder=\"Nama Anggota ").concat(domCount, "\" name='member[").concat(domCount, "][name]' class=\"form-control\" required minlength=\"3\" maxlength=\"100\">\n            <div class=\"invalid-feedback\">\n              Masukkan nama anggota ke-").concat(domCount, "\n            </div>\n          </div>\n        </div>\n      "));
    }
  } // Kalau input yang ditampilan > yang dipilih
  else if (domCount > this.value) {
      for (i = domCount; i > this.value; --i) {
        $('#anggota-wrap-' + domCount).remove();
      }
    }
}); // Reset status "active" button setelah berpindah tab

$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
  $(this).removeClass('active');
});

/***/ }),

/***/ 1:
/*!****************************************!*\
  !*** multi ./resources/js/register.js ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! C:\Users\User\Documents\project\code.amcc.or.id\resources\js\register.js */"./resources/js/register.js");


/***/ })

},[[1,"/js/manifest"]]]);