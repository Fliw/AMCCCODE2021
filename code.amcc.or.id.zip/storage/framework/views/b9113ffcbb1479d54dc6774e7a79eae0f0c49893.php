<?php $__env->startSection('app'); ?>
  <div class="layout-3 main-wrapper container">
    <!-- Basic Navbar -->
    <?php echo $__env->make('app.frontend.partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Main Content -->
    <div class="main-content">
      <?php echo $__env->yieldContent('content'); ?>
		</div>
		
		<!-- Footer -->
    <footer class="main-footer">
      <?php echo $__env->make('app.frontend.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </footer>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app.frontend.layouts.basic.skeleton', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Documents\project\code.amcc.or.id\resources\views/app/frontend/layouts/basic/app.blade.php ENDPATH**/ ?>