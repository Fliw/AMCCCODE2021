<div class="footer-left">
  &copy; <?php echo e(config('app.name')); ?> <div class="bullet"></div> Crafted by <strong>IT Department</strong> of <a href="https://amcc.or.id/">AMCC</a>
</div>
<?php /**PATH C:\Users\User\Documents\project\code.amcc.or.id\resources\views/app/frontend/partials/footer.blade.php ENDPATH**/ ?>