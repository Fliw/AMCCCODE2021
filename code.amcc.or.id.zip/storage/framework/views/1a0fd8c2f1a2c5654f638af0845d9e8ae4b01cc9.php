<?php $__env->startSection('title', 'E-Ticket'); ?>

<?php $__env->startSection('content'); ?>
  <section class="section">
    <div class="section-body">
      <h2 class="section-title">Pilih Tiketmu</h2>
      <p class="section-lead">Tersedia berbagai tiket yang dapat kamu pilih sesuai kebutuhan</p>
      <div class="row">
        <?php $__currentLoopData = $data['tickets']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-lg-6">
            <div class="card card-large-icons">
              <div class="card-icon bg-secondary text-black">
                <i class="fas fa-ticket-alt"></i>
              </div>
              <div class="card-body">
                <h4><?php echo e($ticket['name']); ?></h4>
                <p><?php echo e($ticket['description']); ?></p>
                <a href="<?php echo e(route('ticket.form', ['ticket' => $ticket['slug']])); ?>" class="card-cta">Beli Tiket Ini<i class="fas fa-chevron-right"></i></a>
              </div>
            </div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
  </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app.frontend.layouts.basic.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Documents\project\code.amcc.or.id\resources\views/app/frontend/pages/tickets/index.blade.php ENDPATH**/ ?>