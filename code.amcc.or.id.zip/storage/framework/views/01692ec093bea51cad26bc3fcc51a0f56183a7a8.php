<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
  <title><?php echo $__env->yieldContent('title', 'Home'); ?> &mdash; <?php echo e(config('app.name')); ?></title>
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>">
  <?php echo $__env->yieldPushContent('stylesheet'); ?>
</head>
<body class="layout-3">
  <div id="app">
    <?php echo $__env->yieldContent('app'); ?>
  </div>
  
  <script src="<?php echo e(mix('js/manifest.js')); ?>"></script>
  <script src="<?php echo e(mix('js/vendor.js')); ?>"></script>
  <script src="<?php echo e(mix('js/app.js')); ?>"></script>
  <?php echo $__env->yieldPushContent('javascript'); ?>
</body>
</html>
<?php /**PATH C:\Users\User\Documents\project\code.amcc.or.id\resources\views/app/frontend/layouts/basic/skeleton.blade.php ENDPATH**/ ?>