<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <title>Login Dashboard Tim &mdash; <?php echo e(config('app.name')); ?></title>
  <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>">
</head>

<body>
  <div id="app">
    <section class="section">
      <div class="container mt-5">
        <div class="row">
          <div class="col-12 col-sm-8 offset-sm-2 col-md-6 offset-md-3 col-lg-6 offset-lg-3 col-xl-4 offset-xl-4">
            <div class="login-brand">
              <img src="<?php echo e(asset('code2020/img/logo-384.png')); ?>" alt="logo" width="192">
            </div>
            <?php if(session()->has('error')): ?>
              <div class="alert alert-danger">
                  <?php echo e(session()->get('error')); ?>

              </div>
            <?php endif; ?>

            <div class="card card-primary">
              <form class="needs-validation" action="<?php echo e(route('team.auth')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="card-body">
                  <div class="form-group">
                    <label for="email">Email</label>
                    <input id="email" type="email" class="form-control" name="email" tabindex="1" required autofocus>
                    <div class="invalid-feedback">
                      Please fill in your email
                    </div>
                  </div>
    
                  <div class="form-group">
                    <div class="d-block">
                        <label for="password" class="control-label">Password</label>
                    </div>
                    <input id="password" type="password" class="form-control" name="password" tabindex="2" required>
                    <div class="invalid-feedback">
                      please fill in your password
                    </div>
                  </div>
    
                  <div class="form-group">
                    <button type="submit" class="btn btn-primary btn-lg btn-block" tabindex="4">
                      Login
                    </button>
                    <a href="<?php echo e(route('team.register')); ?>" class="btn btn-default btn-lg btn-block" tabindex="4">
                        Registrasi Tim
                    </a>
                  </div>
                </div>
              </form>
            </div>

            <div class="simple-footer">
              Copyright &copy; <?php echo e(config('app.name')); ?>

            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
  <script src="<?php echo e(mix('js/manifest.js')); ?>"></script>
  <script src="<?php echo e(mix('js/vendor.js')); ?>"></script>
  <script src="<?php echo e(mix('js/app.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\Users\User\Documents\project\code.amcc.or.id\resources\views/app/frontend/pages/team/login.blade.php ENDPATH**/ ?>