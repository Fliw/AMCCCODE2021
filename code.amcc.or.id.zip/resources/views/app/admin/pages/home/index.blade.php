@extends('app.admin.layouts.app')

@section('title', 'Dashboard')

@section('content')
  <section class="section">
    <div class="section-header">
      <h1>Dashboard</h1>
    </div>

    <div class="section-body">
      <div class="row">
        <div class="col-sm-12 col-md-6">

          <h2 class="section-title" style="margin-top: 0">Stats</h2>
          <div class="card">
            <div class="card-body">

            </div>
          </div>
        </div>
      </div>
      
    </div>
  </section>
@endsection
