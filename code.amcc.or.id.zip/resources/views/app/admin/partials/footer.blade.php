<div class="footer-left">
  &copy; {{ config('app.name') }} <div class="bullet"></div> Crafted by <strong>IT Department</strong> of <a href="https://amcc.or.id/">AMCC</a>
</div>
